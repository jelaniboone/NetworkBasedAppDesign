const express = require('express');
const controller = require('../controllers/posterController');
const {fileUpload} = require('../middleware/fileUpload');
const {isLoggedIn, isSeller} = require('../middleware/auth');

const router = express.Router();

//GET /poster: send all posters to the user
router.get('/', controller.index);

//GET /poster/new: send the form to the user
router.get('/new', isLoggedIn, controller.new);

//POST /poster: create a new poster
router.post('/', isLoggedIn, fileUpload, controller.create);

//GET /poster/:id: send a single poster to the user
router.get('/:id', controller.show);

//GET /poster/:id:/edit update a single story
router.get('/:id/edit', isLoggedIn, isSeller, controller.edit);

//PUT /poster/:id: update a single story
router.put('/:id', isLoggedIn, isSeller, fileUpload, controller.update);

//DELETE /poster/:id: delete a single story
router.delete('/:id', isLoggedIn, isSeller, controller.delete);

module.exports = router; //export the router object