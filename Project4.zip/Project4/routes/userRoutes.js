const express = require('express');
const controller = require('../controllers/userController');
const {isGuest, isLoggedIn} = require('../middleware/auth');

const router = express.Router();

//get the new user form
router.get('/new', isGuest, controller.new);

//process the new user request
router.post('/', isGuest, controller.create);

//get login form
router.get('/login', isGuest, controller.login);

//process login request
router.post('/login', isGuest, controller.authenticate);

//get profile page
router.get('/profile', isLoggedIn, controller.profile);

//logout
router.get('/logout', isLoggedIn, controller.logout);



module.exports = router; //export the router object