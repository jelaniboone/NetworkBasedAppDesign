const User = require('../models/user');
const Poster = require('../models/poster');
const { v4: uuidv4 } = require('uuid');

exports.new = (req, res) => {
    res.render('./user/new');
}

exports.create = (req, res, next) => {
    let user = new User(req.body);
        user.save()
        .then (() => {console.log(user), res.render('./user/login')})
        .catch(err => {
            if(err.name === 'ValidationError') {
                req.flash('error', err.message);
                res.redirect('/users/new');

            } else if (err.code === 11000) {
                req.flash('error', 'Email has already been registered');
                res.redirect('/users/new');
            }
            else {
                next(err);
            }
        });
} 

exports.login = (req, res) => {
    return res.render('./user/login');
}

exports.authenticate = (req, res, next) => {
    let email = req.body.email;
    let password = req.body.password;
    //get the user that matches the email
    User.findOne({email: email})
    .then(user => {
        if (user) {
            //user found in the database
            user.comparePassword(password)
            .then(result => {
                if (result) {
                    req.session.user = user._id; //store user's id in the session
                    req.flash('success', 'Welcome back');
                    return res.redirect('/users/profile');
                } else {
                    //console.log('wrong password');
                    req.flash('error', 'Invalid password');
                    return res.redirect('/users/login');
                }
            })
        } else {
            //console.log('wrong email address');
            req.flash('error', 'Invalid email address');
            res.redirect('/users/login');
        }
    })
    .catch(err => next(err));
}

exports.profile = (req, res, next) => {
    let id = req.session.user;
    Promise.all([User.findById(id), Poster.find({seller: id})])
    .then(results => {
        if(results) {
            const [user, posters] = results;
            res.render('./user/profile', {user, posters});
        } else {
            console.log('user not found');
        }
    })
    .catch(err => next(err));
}

exports.logout = (req, res, next) => {
    req.session.destroy(err => {
        if(err) {
            return next(err);
        } else {
            res.redirect('/');
        }
    });
}