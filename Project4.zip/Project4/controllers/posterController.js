const model = require('../models/poster');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');


// exports.index = (req, res) => { 
//     let posters = model.find();
//     res.render('./poster/items.ejs', {posters});
// };

exports.index = (req, res, next)=>{
    let pattern = req.query.search ||'';
    console.log(pattern);
    model.find( { $or: [ { title: { $regex: pattern, $options: 'i' }}, { details: { $regex: pattern, $options: 'i' } } ] })
    .sort({price: 1})
    .then(posters => { //console.log(posters);
        res.render('./poster/items.ejs', {posters})})
    .catch(err=>next(err));
};

exports.new = (req, res) => {
    let posters = model.find();
    res.render('./poster/new', {posters});
};

// exports.create = (req, res) => {
//         let poster = req.body;
//         poster.id = uuidv4();
//         if(req.file) {
//             poster.image = '/images/' + req.file.filename;
//         }
//         console.log(poster);
//         model.save(poster);
//         res.redirect('/poster');
// };  

exports.create = (req, res, next)=>{
    //res.send('Created a new story');
    let poster = new model(req.body);
    poster.seller = req.session.user;
    poster.image = '/images/' + req.file.filename;
    poster.save()//insert model into database
    .then(poster=> { console.log(poster)
    res.redirect('/posters')})
    .catch(err => {
        if(err.name === 'ValidationError') {
            err.status = 400;
        }
        else{
            next(err);
        }
    });
};



// exports.show = (req, res) => {
//     let id = req.params.id;
//     let poster = model.findById(id);
//     console.log(poster);
// res.render('./poster/item', {poster});
// };

exports.show = (req, res, next)=>{
    let id = req.params.id;
    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid poster id');
        res.render('./poster/400', {error: err});
        err.status = 400;
        return next(err);
    }
    model.findById(id).populate('seller', 'firstName lastName')
    .then(poster=> {
        if(poster) {
            console.log(poster);
            res.render('./poster/item', {poster});
        } else {
            let err = new Error('Cannot find a poster with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

// exports.edit = (req, res) => {
//     let id = req.params.id;
//     let poster = model.findById(id);
//     res.render('./poster/edit', {poster});
// };

exports.edit = (req, res, next)=>{
    let id = req.params.id;
    model.findById(id)
    .then(poster=> {
        return res.render('./poster/edit', {poster});
    })
    .catch(err=>next(err));
};

// exports.update = (req, res) => {
//     let poster = req.body;
//     let id = req.params.id;
//     if (req.file) {
//         poster.image = '/images/' + req.file.filename;
//     }
    
//     if(model.updateById(id, poster)) {
//         res.redirect('/poster/' + id);
//     } else {
//         res.status(500).send('Error updating poster');
//     }
// };

exports.update = (req, res, next)=>{
    let poster = req.body;
    let id = req.params.id;
    model.findByIdAndUpdate(id, poster, {useFindAndModify: false, runValidators: true})
    .then(poster=> {
            poster.image = '/images/' + req.file.filename;
            poster.save();
            res.redirect('/posters/'+id);
    })
    .catch(err=> {
        if (err.name === 'ValidationError') {
            err.status = 400;
        }
        next(err);
    });
}



// exports.delete = (req, res) => {
//     let id = req.params.id;
//     if (model.deleteById(id)) {
//         res.redirect('/poster');
//     }
//     else {
//         res.status(500).send('Error deleting poster');
//     }
// };

exports.delete = (req, res, next)=>{
    let id = req.params.id;
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(poster => {
        res.redirect('/posters');
    })
    .catch(err=>next(err));
};