const { DateTime } = require('luxon');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const posterSchema = new Schema({
    title: {type: String, required: [true, 'title is required']},
    condition: {type: String, required: [true, 'condition is required'], 
                              enum: ['new', 'like new', 'good', 'very good', 'other']},
    price: {type: Number, required: [true, 'price is required'], min: [.01, 'price must be at least $.01']},
    details: {type: String, required: [true, 'details is required']},
    seller: {type: Schema.Types.ObjectId, ref: 'User'}, 
    image: {type: String, required: [true, 'image is required']},
    active: {type: Boolean, default: true}
},
{timestamps: true}
);



const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './public/images');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const mimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (mimeTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('File type is not supported. Only jpeg, png, and gif are supported.'), false);
    }
}
exports.upload = multer({storage, 
                       fileFilter,
                       limits: {fileSize: 2*1024*1024}
                    }).single('image');

// 

module.exports = mongoose.model('Poster', posterSchema);