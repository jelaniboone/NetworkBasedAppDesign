const Poster = require('../models/poster');

//check if user is a guest
exports.isGuest = (req, res, next) => {
    if(!req.session.user) {
        return next();
    } else {
        req.flash('error', 'You are already logged in');
        return res.redirect('/users/profile');
    }
}

//check if user is logged in
exports.isLoggedIn = (req, res, next) => {
    if(req.session.user) {
        return next();
    } else {
        req.flash('error', 'You need to log in first');
        return res.redirect('/users/login');
    }
}

//check if user is the seller of the poster
exports.isSeller = (req, res, next) => {
    let id = req.params.id;
    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid poster id');
        res.render('./poster/400', {error: err});
        err.status = 400;
        return next(err);
    }
    Poster.findById(id)
    .then(poster => {
        if (poster) {
            if (poster.seller == req.session.user) {
                return next();
            } else {
                let err = new Error('You are not authorized to do that');
                err.status = 401;
                return res.status(401).render('error', {error: err});
                //return next(err);
            }
        } else {
            let err = new Error('Cannot find a poster with id ' + id);
            err.status = 404;
            return res.status(404).render('error', {error: err});
        }
    })
    .catch(err => next(err));
}