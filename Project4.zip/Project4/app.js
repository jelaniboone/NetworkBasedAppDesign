//require modules
const express = require('express');
const morgan = require('morgan');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const posterRoutes = require('./routes/posterRoutes');
const userRoutes = require('./routes/userRoutes');
const posterController = require('./controllers/posterController');
const userController = require('./controllers/userController');
const methodOverride = require('method-override');
const multer = require('multer');
const path = require('path');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const flash = require('connect-flash');
const User = require('./models/user');
const mongUri = 'mongodb+srv://admin:admin1233@cluster0.h4mqv.mongodb.net/project4?retryWrites=true&w=majority&appName=Cluster0'

//create app
const app = express();

//configure app
let port = 3000;
let host = 'localhost';
//let url = 'mongodb://localhost:27017/project3';
app.set('view engine', 'ejs');

//connect to mongodb
mongoose.connect(mongUri)
.then(() => {
    //start the server
    app.listen(port, host, ()=>{
        console.log('Server is running on port', port);
    })
})
.catch(err => console.log(err.message)); 

/*
//connect to database
mongoose.connect('mongodb://127.0.0.1:27017/project3', 
    {useNewUrlParser: true, useUnifiedTopology: true})
.then(()=>{
    app.listen(port, host, ()=>{
        console.log('Server is running on port', port);
    });
})
.catch(err=>console.log(err.message)); */

//set up session
app.use(session({
    secret: 'fnowksdang;asn',
    resave: false,
    saveUninitialized: false,
    cookie: {maxAge: 60*60*1000},
    store: new MongoStore({mongoUrl: mongUri})
}));

/*app.use((req, res, next) => {
    console.log(req.session);
    next();
}); */

app.use(flash());

app.use((req, res, next)=>{
    res.locals.user = req.session.user || null;
    res.locals.successMessages = req.flash('success');
    res.locals.errorMessages = req.flash('error');
    next();
});

//set up middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({extended: true}));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));
app.use(express.json());


//set up routes
app.get('/', (req, res) => {
    res.render('index', {title: 'Home'});
});

app.use('/posters', posterRoutes); 
app.use('/users', userRoutes);


app.use((req, res, next) => {
    let err = new Error('The server cannot locate ' + req.url);
    err.status = 404;
    next(err);

});
